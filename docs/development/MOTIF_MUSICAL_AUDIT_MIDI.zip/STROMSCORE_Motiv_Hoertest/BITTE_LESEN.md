# STROMSCORE – Motiv-Hörbeispiele, 9a8d01c

Tatsächliche Generatorausgabe, keine nachträglich komponierten Ersatzbeispiele.
100 BPM, 4/4, D, 128 Takte = 5:07,2 Minuten je Datei; Seed 0, Variation im Dateibeispiel hinterlegt.
Interne Fahrt AUS, Szenenlänge unbegrenzt, Aufbau AUS, beide Motivschalter/Legato EIN.

Je Beispiel zwei Dateien: `gesamt` enthält alle neun Ziele, `melodische_Stimmen`
enthält exakt dieselben Melodie-/Dialogereignisse aus diesem Gesamtlauf.
Die zweite Datei wurde nachträglich gefiltert, NICHT mit Solo neu komponiert.
Keine Time-Stretch-/Quantisierungsfunktion beim Import verwenden, Tempo 100 einstellen.
MIDI 960 PPQ. Kanäle 1/2 Harmonie lang/kurz, 3/4 Bass lang/kurz, 5 Arp,
6 Tupfer, 7 Stich, 8 Dialog, 9 Melodie. Studio One kann Oktavnamen anders anzeigen;
die CSV-Dateien verwenden eindeutige MIDI-Notennummern.

Für den Motivvergleich Dialog und Melodie zuerst auf denselben neutralen Klavierklang
routen, dann auf die eigenen Patches. Dies dient nur dem Hörvergleich; die tatsächlichen
Patch-Fähigkeiten und Lautstärken wurden nicht gemessen. Keine GM-Programwechsel.
Spur-/Markernamen enthalten Einführung, Wiederkehr, verwendetes Verfahren und Material-ID.
Eine Material-ID bezeichnet die Herkunft, nicht automatisch unveränderte hörbare Intervalle.
`ANSWER adopted` markiert eine reale Übernahme des Antwortplans; die tatsächlich gespielten
Antwortnoten sind in der CSV nachzulesen. Harmony-Marker geben Grundton relativ zu D und
internen Akkordtyp an; die vollständige Deutung steht im Untersuchungsbericht.

## Hörstellen (Takte ab 1)

- 01 Neutral: erster fünftöniger Gedanke Takt 1, erste Wiederkehr erst Takt 25 (0:57,6).
- 02 Neutral: Einführung Takt 1, anschließend lange Lücke der Hauptmelodie;
  erste Wiederkehr Takt 108 (4:16,8). Dialog bleibt unabhängig aktiv.
- 03 Neutral XYZ langsam: Takt 109 (4:19,2) zeigt den im Bericht belegten
  widersprüchlichen Harmoniebezug eines zwischengespeicherten Rückkehrplans.
- 04 Barry M22: D–D–A–D in Vierteln; Wiederkehr Takt 9, explizite Dialogantwort
  Takt 18, 50, 82 und 114. Die Antwort verwendet die dreitönige Schlussfigur D–A–D,
  in angepasster Lage. Ob daraus ein deutlicher Dialog entsteht, bitte hören.
- 05 Barry M15: D4–A4–D5–A4–D4 über zwei Takte; beide Stimmen können in derselben
  Lage auftreten. Erste Hauptmelodie-Wiederkehr Takt 9.
- 06 Barry M07: acht tatsächlich gespeicherte Töne; bei XYZ-Bewegung längere Lücken.
- 07 Pop: motorische Gegenstimme gegenüber erheblich sparsamerer Hauptmelodie.
- 08 Pop: Wechsel zwischen motorischer und phrasenbezogener Hook-Verwendung;
  gespeichertes Material und live erzeugte Hook-Noten sind nicht gleichzusetzen.

Begleitung ist unverändert. Für reale Instrumente die beiden Längen-Ausgänge separat
zuweisen. Keine Audioaufnahme, keine behauptete akustische Qualitätsabnahme.
Beispiele.json und *_Noten.csv enthalten Tonhöhen, Dauern, Akkordkontext und Wiederkehrdaten.
