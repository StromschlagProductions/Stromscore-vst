# STROMSCORE – Motivik A/B

A = abgenommene Referenz 9a8d01c, B = neue harmonische Konsistenz und Motivwiederkehr.
Je Beispiel 128 Takte, 100 BPM, 4/4, D, 5:07,2 Minuten; Seed 0, Variation in den Messdaten.
Interne Fahrt AUS, Szenenlänge unbegrenzt, Aufbau AUS, beide Stimmen/Motiv-/Legatoschalter EIN.
Beispiel 03 enthält externe XYZ-Bewegung; die übrigen Positionen sind statisch.
Keine nachkomponierten Ersatznoten. `melodische_Stimmen` ist eine nachträgliche Filterung
desselben Gesamtlaufs, keine Solo-Neukomposition. Tempo beim Import auf 100 setzen,
keine Quantisierung/Time-Stretch anwenden. MIDI 960 PPQ. Keine Programmwechsel.

Kanäle: 1 Harmonie lang, 2 Harmonie kurz, 3 Bass lang, 4 Bass kurz, 5 Arp,
6 Tupfer, 7 Stich, 8 Dialog, 9 Melodie. Lang/Kurz auf geeignete Patches routen.
Melodie/Dialog zuerst mit demselben neutralen Klavier vergleichen, dann im eigenen Mix.
MIDI-Nummern in CSV sind eindeutig; Oktavbezeichnungen variieren je DAW.
Marker zeigen Einführung und tatsächlich gespielte Reprisen samt Quellen-ID.
Eine Quellen-ID bezeichnet die Herkunft, nicht automatisch unveränderte Intervalle.

## Hörstellen

01 Neutral: Hauptmelodie Takt 1 C–Es–A–C–Fis. A: nächste Reprise erst Takt 108.
B: vollständige transponierte Reprise bereits Takt 5, nach zwei stillen Takten.
Die spätere lange Lücke ist dadurch nicht generell abgeschafft.
02 Barry M22: D–D–A–D in Vierteln. A: erste Reprise Takt 9.
B: erste transponierte Reprise Takt 4. Die anschließenden Antwortfenster mit anhören.
03 Barry M07: Achtelzelle A–D–Cis–D zweimal. Bewusst ein Grenzfall bei wechselnder
Harmonik; eine frühe geeignete vollständige Reprise ist hier nicht immer möglich.
04 Pop: eigenständiger motorischer Dialoghook und sparsame Hauptmelodie.
Die frühe Reprise der Hauptmelodie vergleichen; der Motor darf kontinuierlich bleiben.

Fläche, Bass und Akzent-Noten bleiben identisch. Arp-Pausen folgen den korrigierten
Motivreservierungen. Keine Änderung von Arp-Muster, Tempo oder Tonwahl.
Bitte Wiedererkennung, Kontur, Atempausen und Zusammenhang beurteilen, nicht nur Lautstärke
oder Notenzahl. Eine akustische Qualitätsabnahme wird durch die MIDI-Messung nicht ersetzt.
