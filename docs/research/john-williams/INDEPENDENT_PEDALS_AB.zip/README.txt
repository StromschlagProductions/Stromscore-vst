A/B aus tatsächlicher Engine-Ausgabe, 100 BPM, D, 4/4, 960 PPQ. A = 1d3c1d5, B = unabhängiges Einzelpedal. Gleiche Instrumente/Kanäle verwenden. Keine Quantisierung. Je 128 Takte.
Standardkanäle: 1 Harmonie lang, 2 Harmonie kurz, 3 Bass lang, 4 Bass kurz, 5 Arpeggio, 6 Tupfer, 7 Stich, 8 Dialog, 9 Melodie.
Zunächst Bass-Lang allein vergleichen, danach das vollständige Arrangement. Ein 16-Takt-Pedal dauert bei 100 BPM 38,4 Sekunden; keine kurzen Acht-Takt-Ausschnitte beurteilen.
